/***************************************************************************
  * Author:  haixiang.bao <haixiang.bao@amlogic.com>
  *
  *Remark: dummy driver for customer
  *
  ***************************************************************************
  */

int dummy(void) 
{
	return 0;
}
