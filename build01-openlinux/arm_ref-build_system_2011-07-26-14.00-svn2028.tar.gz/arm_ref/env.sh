export TOP_DIR=$(pwd)
export KERNEL_DIR=${TOP_DIR}/kernel
export ANDROID_DIR=${TOP_DIR}/android
export ANDROID_KERNEL_DIR=${ANDROID_DIR}/kernel
export BUILD_OUT_DIR=${TOP_DIR}/output
export ROOT_SRC=${TOP_DIR}/buildroot-2010.05
export COMMON_DIR=${TOP_DIR}/common

export BOOT_SRC=${TOP_DIR}/uboot

export KERNEL_SVN=git://10.8.9.8/m1-kernel.git
export ANDROID_KERNEL_GIT=git://10.8.9.8/m1-kernel-android.git
export ANDROID_KERNEL_BRANCH=
export BUILD_ROOT_SVN=https://10.18.11.250/svn/model_linux/branches/buildroot-2010.05
export BOOT_SVN=https://svn-bj.amlogic.com/svn/model_ae/u-boot-arm/trunk 

